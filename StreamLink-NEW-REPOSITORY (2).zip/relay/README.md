# Stream Link Internet Relay

This small Cloudflare Worker is the Internet bridge between the separate phone Sender and TV Receiver apps. It is needed when the phone and TV are on different Wi-Fi networks.

## One-time deployment

1. Create a Cloudflare account and install Wrangler.
2. From this folder run `npx wrangler login`.
3. Run `npx wrangler deploy`.
4. Copy the resulting `https://<your-worker>.<your-subdomain>.workers.dev` URL.
5. Enter that URL once in both Stream Link Sender and Stream Link TV.

No port forwarding is required. The relay stores only the current pending URL for each paired TV and removes it after the TV acknowledges successful receipt. The URL itself is sent as UTF-8 bytes encoded with Base64 and protected by SHA-256 verification.

For a production public deployment, review Cloudflare account limits and add rate limiting/authentication policy appropriate to your use case.
