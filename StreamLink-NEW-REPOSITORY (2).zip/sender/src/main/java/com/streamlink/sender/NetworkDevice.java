package com.streamlink.sender; public final class NetworkDevice { public final String name,host; public NetworkDevice(String n,String h){name=n;host=h;} }
