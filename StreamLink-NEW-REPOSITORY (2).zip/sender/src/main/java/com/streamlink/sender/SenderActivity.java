package com.streamlink.sender;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import java.util.concurrent.Executors;

/** Phone-first Stream Link Sender. Pair once, then send URLs without reconnecting. */
public final class SenderActivity extends Activity {
    private static final String PREF = "stream_link_sender";
    private EditText urlInput, codeInput, relayInput;
    private TextView connectionText, statusText;
    private Button pairButton, sendButton;
    private final java.util.concurrent.ExecutorService executor = Executors.newSingleThreadExecutor();

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private int bg(String hex) { return Color.parseColor(hex); }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg("#0B0D10"));
        getWindow().setNavigationBarColor(bg("#0B0D10"));
        buildUi();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (text != null && urlInput != null) urlInput.setText(text);
        }
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(Color.WHITE); t.setTextSize(15); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(2), dp(12), dp(2), dp(7)); return t;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(bg("#77808C")); e.setTextColor(Color.WHITE); e.setTextSize(16);
        e.setSingleLine(true); e.setPadding(dp(16), 0, dp(16), 0); e.setBackground(inputBg());
        return e;
    }

    private GradientDrawable inputBg() {
        GradientDrawable g = new GradientDrawable(); g.setColor(bg("#171A20")); g.setCornerRadius(dp(12)); g.setStroke(dp(1), bg("#303641")); return g;
    }

    private Button action(String text, boolean primary) {
        Button b = new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setMinHeight(dp(52));
        GradientDrawable g = new GradientDrawable(); g.setColor(bg(primary ? "#1687F5" : "#252A33")); g.setCornerRadius(dp(12));
        b.setBackground(g); return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg("#0B0D10"));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(18), dp(20), dp(28));
        scroll.addView(root);

        TextView brand = new TextView(this); brand.setText("STREAM LINK"); brand.setTextColor(bg("#56B2FF")); brand.setTextSize(13); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD); root.addView(brand);
        TextView title = new TextView(this); title.setText("Sender"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Send a video URL to your TV over the Internet"); sub.setTextColor(bg("#9AA3AE")); sub.setTextSize(15); sub.setPadding(0, dp(3), 0, dp(16)); root.addView(sub);

        LinearLayout statusCard = card();
        connectionText = new TextView(this); connectionText.setTextColor(Color.WHITE); connectionText.setTextSize(15); connectionText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        statusCard.addView(connectionText, new LinearLayout.LayoutParams(-1, -2));
        TextView statusHint = new TextView(this); statusHint.setText("Your TV connection is saved on this phone."); statusHint.setTextColor(bg("#89929E")); statusHint.setTextSize(13); statusCard.addView(statusHint);
        root.addView(statusCard, marginParams(dp(0), dp(0), dp(0), dp(10)));

        root.addView(label("VIDEO URL"));
        urlInput = field("Paste or share a video URL"); urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(urlInput, heightParams(dp(58), dp(0)));

        sendButton = action("Send to TV", true); root.addView(sendButton, marginParams(dp(0), dp(12), dp(0), dp(0))); sendButton.setOnClickListener(v -> send());
        Button share = action("Share URL to Stream Link", false); root.addView(share, marginParams(dp(0), dp(8), dp(0), dp(0)));
        share.setOnClickListener(v -> { String u=urlInput.getText().toString().trim(); if(!u.isEmpty()){ Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,u); startActivity(Intent.createChooser(i,"Send URL with")); }});

        root.addView(label("FIRST-TIME SETUP"));
        relayInput = field("Relay server URL (one-time setup)"); relayInput.setText(getPreferences(0).getString("relay", "")); root.addView(relayInput, heightParams(dp(58), 0));
        codeInput = field("6-digit TV pairing code"); codeInput.setInputType(InputType.TYPE_CLASS_NUMBER); root.addView(codeInput, marginHeight(dp(8), dp(58)));
        pairButton = action("Pair with TV", false); root.addView(pairButton, marginParams(0, dp(8), 0, 0)); pairButton.setOnClickListener(v -> pair());

        statusText = new TextView(this); statusText.setTextColor(bg("#AAB3BE")); statusText.setTextSize(14); statusText.setGravity(Gravity.CENTER); statusText.setPadding(0, dp(16), 0, 0); root.addView(statusText, new LinearLayout.LayoutParams(-1, dp(70)));
        setContentView(scroll); updateStatus();
    }

    private LinearLayout card() { LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(15),dp(12),dp(15),dp(12)); GradientDrawable g=new GradientDrawable();g.setColor(bg("#14171C"));g.setCornerRadius(dp(14));g.setStroke(dp(1),bg("#2A3039"));c.setBackground(g);return c; }
    private LinearLayout.LayoutParams heightParams(int h,int top){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(h)); p.topMargin=top; return p; }
    private LinearLayout.LayoutParams marginHeight(int top,int h){ return heightParams(h,top); }
    private LinearLayout.LayoutParams marginParams(int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(l),t==0?0:dp(t),dp(r),dp(b));return p; }

    private String saved(String key){ return getPreferences(0).getString(key, ""); }
    private void pair() {
        String code=codeInput.getText().toString().trim(), base=relayInput.getText().toString().trim();
        if(code.length()!=6 || base.isEmpty()){ setStatus("Enter the 6-digit TV code and relay URL."); return; }
        getPreferences(0).edit().putString("relay",base).apply(); setStatus("Pairing securely…"); pairButton.setEnabled(false);
        executor.execute(() -> { try { RelayClient.Paired p=new RelayClient(base).claim(code); getPreferences(0).edit().putString("deviceId",p.deviceId).putString("token",p.senderToken).apply(); runOnUiThread(()->{setStatus("TV paired successfully. You can now send URLs anytime."); updateStatus(); pairButton.setEnabled(true);}); } catch(Exception e){runOnUiThread(()->{setStatus("Pairing failed. Check the code and relay URL.");pairButton.setEnabled(true);});} });
    }

    private void send() {
        String u=urlInput.getText().toString().trim(), base=saved("relay"), id=saved("deviceId"), token=saved("token");
        if(u.isEmpty()){setStatus("Paste a video URL first.");return;} if(base.isEmpty()||id.isEmpty()||token.isEmpty()){setStatus("Pair with your TV once before sending.");return;}
        setStatus("Sending securely…"); sendButton.setEnabled(false);
        executor.execute(()->{try{boolean ok=new RelayClient(base).send(id,token,u);runOnUiThread(()->{setStatus(ok?"Delivered to TV ✓":"Delivery failed. Please try again.");sendButton.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{setStatus("Could not reach the TV. Retrying is safe.");sendButton.setEnabled(true);});}});
    }
    private void updateStatus(){ if(connectionText==null)return; connectionText.setText(saved("deviceId").isEmpty()?"Not connected":"Connected • TV ready"); }
    private void setStatus(String s){ if(statusText!=null)statusText.setText(s); }
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
