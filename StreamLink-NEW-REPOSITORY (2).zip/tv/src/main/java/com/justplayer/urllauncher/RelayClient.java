package com.justplayer.urllauncher;

import android.util.Base64;
import org.json.JSONObject;
import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.security.MessageDigest;

public final class RelayClient {
 private final String base; public RelayClient(String b){base=b.replaceAll("/+$","");}
 private String req(String method,String path,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(base+path).openConnection();c.setRequestMethod(method);c.setConnectTimeout(8000);c.setReadTimeout(15000);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");if(body!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}int n=c.getResponseCode();InputStream in=n>=200&&n<300?c.getInputStream():c.getErrorStream();String s=read(in);if(n<200||n>=300)throw new IOException("Relay HTTP "+n+": "+s);return s;}
 private static String read(InputStream i)throws Exception{if(i==null)return "";try(BufferedReader r=new BufferedReader(new InputStreamReader(i,StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String x;while((x=r.readLine())!=null)b.append(x);return b.toString();}}
 public Pairing createPair()throws Exception{JSONObject j=new JSONObject(req("POST","/pair/create","{}"));return new Pairing(j.getString("deviceId"),j.getString("deviceToken"),j.getString("code"));}
 public Message poll(String id,String token)throws Exception{JSONObject j=new JSONObject(req("POST","/poll/"+URLEncoder.encode(id,"UTF-8"),new JSONObject().put("token",token).toString()));if(!j.optBoolean("ok")||!j.has("payload"))return null;byte[] bytes=Base64.decode(j.getString("payload"),Base64.NO_WRAP);String hash=hex(MessageDigest.getInstance("SHA-256").digest(bytes));if(j.has("length") && j.getInt("length")!=bytes.length)throw new IOException("Length check failed");if(!hash.equalsIgnoreCase(j.getString("sha256")))throw new IOException("Integrity check failed");return new Message(new String(bytes,StandardCharsets.UTF_8),j.getString("messageId"));}
 public void ack(String id,String token,String msgId,boolean ok)throws Exception{req("POST","/ack/"+URLEncoder.encode(id,"UTF-8"),new JSONObject().put("token",token).put("messageId",msgId).put("ok",ok).toString());}
 private static String hex(byte[] a){StringBuilder b=new StringBuilder();for(byte x:a)b.append(String.format("%02x",x));return b.toString();}
 public static final class Pairing{public final String deviceId,deviceToken,code;Pairing(String a,String b,String c){deviceId=a;deviceToken=b;code=c;}}
 public static final class Message{public final String url,id;Message(String u,String i){url=u;id=i;}}
}
