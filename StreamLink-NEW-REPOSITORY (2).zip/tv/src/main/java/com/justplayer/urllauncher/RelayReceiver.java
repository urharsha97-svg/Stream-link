package com.justplayer.urllauncher;

import android.content.Context; import android.os.*; import java.util.concurrent.atomic.AtomicBoolean;

public final class RelayReceiver implements AutoCloseable {
 public interface Listener{void onUrl(String url);}
 private final String base; private final Handler h=new Handler(Looper.getMainLooper()); private final AtomicBoolean running=new AtomicBoolean(false); private Thread t;
 public RelayReceiver(String base){this.base=base;}
 public void start(String deviceId,String token,Listener l){if(running.getAndSet(true))return;t=new Thread(()->{while(running.get()){try{RelayClient.Message m=new RelayClient(base).poll(deviceId,token);if(m!=null){try{l.onUrl(m.url);new RelayClient(base).ack(deviceId,token,m.id,true);}catch(Exception e){try{new RelayClient(base).ack(deviceId,token,m.id,false);}catch(Exception ignored){}}}Thread.sleep(1800);}catch(Exception e){try{Thread.sleep(3000);}catch(InterruptedException ignored){}}}});t.start();}
 public void close(){running.set(false);if(t!=null)t.interrupt();}
}
